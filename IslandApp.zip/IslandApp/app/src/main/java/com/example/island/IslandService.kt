package com.example.island

import android.app.*
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.MediaMetadata
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.*
import android.text.InputType
import android.util.Base64
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.min

class IslandService : Service() {
    // Если Google сменит название модели, поменяй здесь:
    private val MODEL = "gemini-3.8-flash"
    private val PROMPT = "Опиши кратко, что на этом экране, и подскажи, что можно сделать. Отвечай по-русски."

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var pill: LinearLayout
    private lateinit var header: TextView
    private lateinit var batt: TextView
    private lateinit var topRow: LinearLayout
    private lateinit var notifBox: TextView
    private var notifPi: PendingIntent? = null
    private var homeX = 0               // сохранённое положение по горизонтали (lp.x может временно сдвигаться, чтобы панель влезла)
    private lateinit var panel: LinearLayout
    private lateinit var playBtn: TextView
    private lateinit var answer: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private var history = JSONArray()   // переписка с ИИ (для дополнительных вопросов)
    private var log = ""
    private var chatGen = 0             // номер чата: ответы от сброшенного чата игнорируются
    private lateinit var lp: WindowManager.LayoutParams
    private var expanded = false
    private var moveMode = false
    private val posPrefs get() = getSharedPreferences("island", MODE_PRIVATE)
    private fun orient() = realSize().let { if (it.first > it.second) "land" else "port" }
    private var controller: MediaController? = null

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
        private var started = false

    private val dp get() = resources.displayMetrics.density

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, f: Int, id: Int): Int {
        if (started || intent == null) return START_NOT_STICKY
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("island", "Island", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "island")
            .setContentTitle("Island работает").setSmallIcon(android.R.drawable.ic_menu_compass).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra("data", Intent::class.java)
                   else @Suppress("DEPRECATION") intent.getParcelableExtra("data")
        projection = mpm.getMediaProjection(intent.getIntExtra("code", 0), data!!).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, ui)
        }
        started = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        setupCapture()
        buildIsland()
        MediaListener.onNotif = { app, title, text, pi -> ui.post { showNotif(app, title, text, pi) } }
        tick.run()
        return START_NOT_STICKY
    }

    // ---------- Интерфейс острова ----------
    private fun tv(t: String, size: Float = 15f, click: (() -> Unit)? = null) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding((12 * dp).toInt(), (8 * dp).toInt(), (12 * dp).toInt(), (8 * dp).toInt())
        click?.let { c -> setOnClickListener { c() } }
    }

    private fun buildIsland() {
        pill = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(Color.BLACK); cornerRadius = 26 * dp }
            setPadding((8 * dp).toInt(), (2 * dp).toInt(), (8 * dp).toInt(), (6 * dp).toInt())
        }
        val toggle = {
            expanded = !expanded
            if (!expanded) closeKeyboard()
            panel.visibility = if (expanded) View.VISIBLE else View.GONE
            applyLayout()
        }
        header = tv("", 14f) { toggle() }.apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        batt = tv("", 13f) { toggle() }.apply { setPadding(0, (8 * dp).toInt(), (12 * dp).toInt(), (8 * dp).toInt()) }
        val dragListener = object : View.OnTouchListener {
            var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                if (!moveMode) return false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = homeX; sy = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val ox = e.rawX - dx; val oy = e.rawY - dy
                        if (Math.abs(ox) > 10 * dp || Math.abs(oy) > 10 * dp) moved = true
                        if (moved) {
                            val (w, h, _) = realSize()
                            val lim = (w / 2 - 30 * dp).toInt()   // можно уводить почти за край экрана
                            homeX = (sx + ox).toInt().coerceIn(-lim, lim); lp.x = homeX
                            lp.y = (sy + oy).toInt().coerceIn(minY(), h - (80 * dp).toInt())
                            wm.updateViewLayout(pill, lp)
                        }
                    }
                    MotionEvent.ACTION_UP -> { if (moved) savePosition() else endMove() }
                }
                return true
            }
        }
        header.setOnTouchListener(dragListener); batt.setOnTouchListener(dragListener)
        topRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; addView(header); addView(batt) }
        pill.addView(topRow)

        notifBox = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f; maxLines = 3; visibility = View.GONE
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding((12 * dp).toInt(), (4 * dp).toInt(), (12 * dp).toInt(), (8 * dp).toInt())
            setOnClickListener { openNotif() }
        }
        pill.addView(notifBox)

        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row.addView(tv("⏮", 22f) { controller?.transportControls?.skipToPrevious() })
        playBtn = tv("⏯", 22f) {
            val c = controller
            if (c?.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
            else c?.transportControls?.play()
        }
        row.addView(playBtn)
        row.addView(tv("⏭", 22f) { controller?.transportControls?.skipToNext() })
        panel.addView(row)
        input = EditText(this).apply {
            hint = "Свой вопрос (можно пусто)"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT; imeOptions = EditorInfo.IME_ACTION_SEND
            background = GradientDrawable().apply { setColor(0xFF222222.toInt()); cornerRadius = 14 * dp }
            setPadding((12 * dp).toInt(), (8 * dp).toInt(), (12 * dp).toInt(), (8 * dp).toInt())
            setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_SEND) { send(false); true } else false }
            setOnKeyListener { _, code, ev ->
                if (code == KeyEvent.KEYCODE_BACK && ev.action == KeyEvent.ACTION_UP) { closeKeyboard(); true } else false
            }
            setOnFocusChangeListener { _, has -> if (!has) setWindowFocusable(false) }
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_DOWN) {
                    setWindowFocusable(true)
                    ui.postDelayed({
                        requestFocus()
                        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                            .showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
                    }, 150)
                }
                false
            }
        }
        panel.addView(input, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (4 * dp).toInt(); bottomMargin = (2 * dp).toInt() })
        val rowAsk = LinearLayout(this).apply { gravity = Gravity.CENTER }
        rowAsk.addView(tv("➤ Спросить") { send(false) })
        rowAsk.addView(tv("👁 Новый экран") { send(true) })
        panel.addView(rowAsk)
        panel.addView(tv("🗑 Сбросить чат", 13f) { resetChat() })
        val row2 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row2.addView(tv("✥ Переместить", 13f) { startMove() })
        row2.addView(tv("↺ Сбросить место", 13f) {
            homeX = 0; lp.y = minY(); fitX(); savePosition(); wm.updateViewLayout(pill, lp)
        })
        panel.addView(row2)
        answer = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 14f; setPadding((8 * dp).toInt(), 0, (8 * dp).toInt(), 0) }
        scroll = ScrollView(this).apply { addView(answer); visibility = View.GONE }
        panel.addView(scroll)
        pill.addView(panel)

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = (6 * dp).toInt()
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
            // разрешаем заходить на строку состояния и вырез камеры
            if (Build.VERSION.SDK_INT >= 30) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            else if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        applyPosition()
        wm.addView(pill, lp)
        applyLayout()
    }

    /** Строка состояния перехватывает нажатия, поэтому остров должен хотя бы нижней частью быть под ней. */
    private fun minY(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        val sb = if (id > 0) resources.getDimensionPixelSize(id) else (24 * dp).toInt()
        return maxOf(0, sb - (10 * dp).toInt())
    }

    private fun applyPosition() {
        val o = orient()
        homeX = (posPrefs.getFloat("x_$o", 0f) * dp).toInt()
        fitX()
        val savedY = posPrefs.getFloat("y_$o", -1f)
        lp.y = if (savedY < 0) minY() else maxOf((savedY * dp).toInt(), minY())
        if (pill.isAttachedToWindow) wm.updateViewLayout(pill, lp)
    }

    private fun savePosition() {
        val o = orient()
        posPrefs.edit().putFloat("x_$o", homeX / dp).putFloat("y_$o", lp.y / dp).apply()
    }

    private fun startMove() {
        closeKeyboard()
        ui.removeCallbacks(hideNotif); notifBox.visibility = View.GONE; batt.visibility = View.GONE
        moveMode = true; expanded = false; panel.visibility = View.GONE
        header.text = "✥ Тащи меня · тап = готово"
        applyLayout()
    }

    private fun endMove() {
        moveMode = false
        batt.visibility = View.VISIBLE
        header.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
    }

    private fun notifVisible() = notifBox.visibility == View.VISIBLE

    /** Когда остров раскрыт (или показывает уведомление), сдвигаем его так, чтобы он целиком был на экране. */
    private fun fitX() {
        val w = realSize().first
        val width = if (expanded || notifVisible()) min(300 * dp, w - 24 * dp) else 0f
        if (width <= 0f) { lp.x = homeX; return }
        val lim = ((w - width) / 2f).toInt().coerceAtLeast(0)
        lp.x = homeX.coerceIn(-lim, lim)
    }

    // ---------- Уведомления ----------
    private val hideNotif = Runnable {
        notifBox.visibility = View.GONE; notifPi = null; applyLayout()
    }

    private fun showNotif(app: String, title: String, text: String, pi: PendingIntent?) {
        if (moveMode) return
        notifPi = pi
        val body = (if (title.isNotEmpty()) "$title: " else "") + text
        notifBox.text = "🔔 $app\n$body"
        notifBox.visibility = View.VISIBLE
        applyLayout()
        ui.removeCallbacks(hideNotif)
        ui.postDelayed(hideNotif, 6000)
    }

    private fun openNotif() {
        val pi = notifPi
        ui.removeCallbacks(hideNotif); hideNotif.run()
        try {
            val opts = ActivityOptions.makeBasic().apply {
                if (Build.VERSION.SDK_INT >= 34)
                    setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
            }
            pi?.send(this, 0, null, null, null, null, opts.toBundle())
        } catch (e: Exception) { }
    }

    /** Подгоняет размеры под текущую ориентацию (портрет / альбом). */
    private fun applyLayout() {
        val m = DisplayMetrics().also { @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(it) }
        header.maxWidth = (min(m.widthPixels * 0.6f, 220 * dp)).toInt()
        notifBox.maxWidth = min(280 * dp, m.widthPixels - 40 * dp).toInt()
        pill.minimumWidth = when {
            expanded -> min(300 * dp, m.widthPixels - 24 * dp).toInt()
            notifVisible() -> min(260 * dp, m.widthPixels - 24 * dp).toInt()
            else -> 0
        }
        scroll.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, (m.heightPixels * 0.35f).toInt())
        scroll.visibility = if (expanded && answer.text.isNotEmpty()) View.VISIBLE else View.GONE
        fitX()
        if (pill.isAttachedToWindow) wm.updateViewLayout(pill, lp)
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (started) { applyLayout(); applyPosition(); resetCapture() }
    }

    // ---------- Музыка + часы ----------
    private val tick = object : Runnable {
        override fun run() {
            if (moveMode) { ui.postDelayed(this, 2000); return }
            try {
                val msm = getSystemService(MediaSessionManager::class.java)
                controller = msm.getActiveSessions(ComponentName(this@IslandService, MediaListener::class.java)).firstOrNull()
            } catch (e: SecurityException) { controller = null }
            val title = controller?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
            val playing = controller?.playbackState?.state == PlaybackState.STATE_PLAYING
            val t = if (!title.isNullOrBlank()) (if (playing) "♪ " else "⏸ ") + title
                    else SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            if (header.text.toString() != t) header.text = t

            // заряд батареи
            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val st = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (lvl >= 0 && scale > 0) lvl * 100 / scale else -1
            val bt = if (pct < 0) "" else (if (charging) "⚡" else "") + "$pct%"
            if (batt.text.toString() != bt) batt.text = bt
            batt.setTextColor(when {
                charging -> 0xFF4CD964.toInt()
                pct in 0..14 -> Color.RED
                else -> Color.WHITE
            })
            ui.postDelayed(this, 2000)
        }
    }

    // ---------- Захват экрана + ИИ ----------
    private fun realSize(): Triple<Int, Int, Int> {
        val m = DisplayMetrics().also { @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(it) }
        return Triple(m.widthPixels, m.heightPixels, m.densityDpi)
    }

    // Захват включается только на момент снимка, иначе телефон постоянно копирует каждый кадр и тормозит.
    private fun setupCapture() {
        val (w, h, dpi) = realSize()
        vd = projection!!.createVirtualDisplay("island", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, null, null, null)
    }

    private fun resetCapture() {
        val (w, h, dpi) = realSize()
        vd?.resize(w, h, dpi)
    }

    private fun startCapture() {
        val (w, h, _) = realSize()
        reader?.close()
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd?.surface = reader!!.surface
    }

    private fun stopCapture() {
        vd?.surface = null
        reader?.close()
        reader = null
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        val pl = img.planes[0]
        val w = img.width; val h = img.height
        val pad = pl.rowStride - pl.pixelStride * w
        val raw = Bitmap.createBitmap(w + pad / pl.pixelStride, h, Bitmap.Config.ARGB_8888)
        raw.copyPixelsFromBuffer(pl.buffer)
        img.close()
        return Bitmap.createBitmap(raw, 0, 0, w, h)
    }

    private fun apiKey() = getSharedPreferences("island", MODE_PRIVATE).getString("key", "") ?: ""

    /** Окно острова становится "фокусным" только пока печатаешь, иначе оно мешало бы кнопке «Назад» в других приложениях. */
    private fun setWindowFocusable(on: Boolean) {
        val f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        val n = lp.flags
        lp.flags = if (on) (n and f.inv()) or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL else n or f
        if (lp.flags != n && pill.isAttachedToWindow) wm.updateViewLayout(pill, lp)
    }

    private fun closeKeyboard() {
        if (!::input.isInitialized) return
        input.clearFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
        setWindowFocusable(false)
    }

    /** newScreen = true: сделать новый снимок экрана; иначе (если диалог уже идёт) задать дополнительный вопрос. */
    private fun send(newScreen: Boolean) {
        val q = input.text.toString().trim()
        input.setText("")
        closeKeyboard()
        if (newScreen || history.length() == 0) askAboutScreen(if (q.isEmpty()) PROMPT else q)
        else if (q.isNotEmpty()) followUp(q)
    }

    private fun resetChat() {
        chatGen++
        history = JSONArray(); log = ""
        input.setText("")
        closeKeyboard()
        pill.visibility = View.VISIBLE
        show("")
    }

    private fun askAboutScreen(question: String) {
        val key = apiKey()
        if (key.isEmpty()) { show("Нет ключа Gemini: открой приложение Island и вставь его."); return }
        history = JSONArray(); chatGen++
        val gen = chatGen
        log = "Вы: " + (if (question == PROMPT) "Что на экране?" else question) + "\n\n"
        show(log + "Смотрю на экран…")
        pill.visibility = View.INVISIBLE            // чтобы остров не попал в кадр
        startCapture()
        var tries = 0
        val poll = object : Runnable {
            override fun run() {
                val shot = grab()
                if (shot == null && ++tries < 20) { ui.postDelayed(this, 100); return }
                stopCapture()
                pill.visibility = View.VISIBLE
                if (shot == null) { show(log + "Не удалось снять экран."); return }
                Thread {
                    val text = try { callGemini(key, shot, question) } catch (e: Exception) { "Ошибка: ${e.message}" }
                    ui.post { finishAnswer(text, gen) }
                }.start()
            }
        }
        ui.postDelayed(poll, 300)
    }

    private fun followUp(q: String) {
        val key = apiKey()
        if (key.isEmpty()) { show("Нет ключа Gemini: открой приложение Island и вставь его."); return }
        val gen = chatGen
        log += "Вы: $q\n\n"
        show(log + "Думаю…")
        Thread {
            val text = try { callGemini(key, null, q) } catch (e: Exception) { "Ошибка: ${e.message}" }
            ui.post { finishAnswer(text, gen) }
        }.start()
    }

    private fun finishAnswer(text: String, gen: Int) {
        if (gen != chatGen) return
        log += "ИИ: $text\n\n"
        show(log)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun show(t: String) { answer.text = t; applyLayout() }

    private fun callGemini(key: String, shot: Bitmap?, question: String): String {
        val h = history
        val parts = JSONArray().put(JSONObject().put("text",
            if (question == PROMPT) question else question + "\n(Отвечай по-русски и кратко.)"))
        if (shot != null) {
            val k = 1024f / maxOf(shot.width, shot.height)
            val small = Bitmap.createScaledBitmap(shot, (shot.width * k).toInt(), (shot.height * k).toInt(), true)
            val out = ByteArrayOutputStream().also { small.compress(Bitmap.CompressFormat.JPEG, 80, it) }
            val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
            parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64)))
        }
        h.put(JSONObject().put("role", "user").put("parts", parts))
        val body = JSONObject().put("contents", h)
        fun undo() { h.remove(h.length() - 1) }
        try {
            var resp = ""; var ok = false; var code = 0
            for (attempt in 1..4) {                      // при перегрузке Google повторяем запрос
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent?key=$key")
                    .openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                code = c.responseCode
                ok = code in 200..299
                resp = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
                if (ok || (code != 503 && code != 429)) break
                Thread.sleep(2500L * attempt)
            }
            if (!ok) {
                undo()
                return if (code == 503) "Gemini сейчас перегружен. Попробуй ещё раз через минуту."
                       else "Ошибка $code: " + resp.take(300)
            }
            val text = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            h.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", text))))
            return text
        } catch (e: Exception) { undo(); throw e }
    }

    override fun onDestroy() {
        MediaListener.onNotif = null
        ui.removeCallbacksAndMessages(null)
        if (::pill.isInitialized && pill.isAttachedToWindow) wm.removeView(pill)
        vd?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
}
