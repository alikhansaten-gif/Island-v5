package com.example.island

import android.app.Notification
import android.app.PendingIntent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Даёт Android разрешение на доступ к музыке (медиа-сессиям)
 * и передаёт острову новые уведомления.
 */
class MediaListener : NotificationListenerService() {
    companion object {
        @Volatile
        var onNotif: ((app: String, title: String, text: String, pi: PendingIntent?) -> Unit)? = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            val n = sbn.notification
            if (sbn.packageName == packageName) return
            if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return      // музыка, звонки, службы
            if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
            if (n.category == Notification.CATEGORY_TRANSPORT || n.category == Notification.CATEGORY_PROGRESS) return
            val ex = n.extras
            val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
            if (title.isEmpty() && text.isEmpty()) return
            val app = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
            } catch (e: Exception) { sbn.packageName }
            onNotif?.invoke(app, title, text, n.contentIntent)
        } catch (e: Exception) { }
    }
}
