Island для Android
1. Android Studio -> File -> Open -> папка IslandApp. Дождись синхронизации Gradle.
2. Подключи телефон (отладка по USB) и нажми Run. Или Build -> Build APK(s).
3. В приложении: вставь ключ Gemini, шаг 1, шаг 2, шаг 3.
